using UnityEngine;
using System.Collections;

public class MusicBox1 : MonoBehaviour
{
    public Transform player;        
    public AudioSource audioSource; 
    public float maxVolume = 1.0f;  
    public float maxDistance = 10.0f;  
    public float minDistance = 1.0f;  
    public GameObject Mob;         
    public AudioSource horrormusic; 
    public Animator animator;      

    private bool hasTriggered = false;

    private void Start()
    {
        Mob.gameObject.SetActive(false); 
        animator = GetComponent<Animator>();
    }

    private void Update()
    {
        
        float distance = Vector3.Distance(player.position, transform.position);

        
        float volume = Mathf.Clamp(1 - (distance - minDistance) / (maxDistance - minDistance), 0, 1) * maxVolume;

       
        audioSource.volume = volume;
    }

    private void OnTriggerEnter(Collider other)
    {
        if (other.tag == "Player" && !hasTriggered) 
        {
            hasTriggered = true; 

            audioSource.Stop(); 
            horrormusic.Play(); 
            Mob.gameObject.SetActive(true); 
            StartCoroutine(HideMobAfterDelay(2f)); 
        }
    }

    private IEnumerator HideMobAfterDelay(float delay)
    {
        yield return new WaitForSeconds(delay); 
        Mob.gameObject.SetActive(false);
    }
}
