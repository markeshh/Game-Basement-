﻿using UnityEngine;

public class Headbob : MonoBehaviour
{
    [SerializeField] private Transform cameraTransform;
    [SerializeField] private PlayerController playerController;
    [SerializeField] private float bobSpeed = 1.0f;
    [SerializeField] private float bobAmount = 0.05f;
    [SerializeField] private float sprintBobAmount = 0.08f;
    [SerializeField] private float bobLerpSpeed = 5.0f; // Параметр для плавного перехода

    private Vector3 originalCameraPosition;
    private float timer = 0;

    private float currentBobAmount; // Текущая амплитуда "Headbob"

    private void Start()
    {
        if (cameraTransform == null)
        {
            Debug.LogError("Camera transform is not assigned to the Headbob script.");
            enabled = false;
            return;
        }

        originalCameraPosition = cameraTransform.localPosition;
        currentBobAmount = bobAmount; // Изначально устанавливаем амплитуду "Headbob" как обычно
    }

    private void Update()
    {
        // Проверяем, двигается ли игрок
        bool isMoving = playerController.IsMoving();

        // Если игрок двигается, то применяем эффект "Headbob"
        if (isMoving)
        {
            timer += Time.deltaTime * bobSpeed;
            float bobX = Mathf.Sin(timer) * currentBobAmount;
            float bobY = Mathf.Cos(timer * 2) * currentBobAmount;

            // Применяем движение камеры
            cameraTransform.localPosition = originalCameraPosition + new Vector3(bobX, bobY, 0);
        }
        else
        {
            // Возвращаем камеру в исходное положение, если игрок не двигается
            cameraTransform.localPosition = Vector3.Lerp(cameraTransform.localPosition, originalCameraPosition, Time.deltaTime * bobLerpSpeed);
        }

        // Плавно изменяем амплитуду "Headbob" при активации и деактивации спринта
        if (playerController.IsSprinting())
        {
            currentBobAmount = Mathf.Lerp(currentBobAmount, sprintBobAmount, Time.deltaTime * bobLerpSpeed);
        }
        else
        {
            currentBobAmount = Mathf.Lerp(currentBobAmount, bobAmount, Time.deltaTime * bobLerpSpeed);
        }
    }
}