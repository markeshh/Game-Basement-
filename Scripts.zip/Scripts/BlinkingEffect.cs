using System.Collections;
using UnityEngine;
using UnityEngine.UI;

public class BlinkingEffect : MonoBehaviour
{
    [SerializeField] private float blinkInterval = 3.0f;
    [SerializeField] private float blinkDuration = 0.1f;
    [SerializeField] private Image screenOverlay; 

    private Color transparentColor = new Color(0, 0, 0, 0); 
    private Color blackColor = new Color(0, 0, 0, 1); 

    private void Start()
    {
        screenOverlay.color = transparentColor;
        StartCoroutine(BlinkScreen());
    }

    private IEnumerator BlinkScreen()
    {
        while (true)
        {
            float elapsedTime = 0f;

            while (elapsedTime < blinkDuration)
            {
                screenOverlay.color = Color.Lerp(transparentColor, blackColor, elapsedTime / blinkDuration);
                elapsedTime += Time.deltaTime;
                yield return null;
            }
            screenOverlay.color = blackColor;

            yield return new WaitForSeconds(blinkDuration);

            elapsedTime = 0f;

            while (elapsedTime < blinkDuration)
            {
                screenOverlay.color = Color.Lerp(blackColor, transparentColor, elapsedTime / blinkDuration);
                elapsedTime += Time.deltaTime;
                yield return null;
            }
            screenOverlay.color = transparentColor;

            yield return new WaitForSeconds(blinkInterval - blinkDuration);
        }
    }
}
