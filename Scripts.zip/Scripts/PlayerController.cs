﻿using UnityEngine;

public class PlayerController : MonoBehaviour
{
    [Header("Movement")]
    [SerializeField] private float moveSpeed = 5.0f;
    [SerializeField] private float rotationSpeed = 2.0f;
    [SerializeField] private float lookSpeed = 2.0f;
    [SerializeField] private float lookLimit = 80.0f;
    [SerializeField] private float sprintSpeed = 10.0f;
    [SerializeField] private float stamina = 100.0f;
    [SerializeField] private float staminaDepletionRate = 10.0f;

    [Header("Footstep Sounds")]
    public AudioSource footstepAudioSource;
    public float nextWalkFootstepDelay = 0.5f;
    public float nextSprintFootstepDelay = 0.3f;

    public AudioClip[] woodFootstepSounds;
    public AudioClip[] metalFootstepSounds;
    public AudioClip[] groundFootstepSounds;
    public AudioSource BreatheSound;

    [Header("Gravity")]
    [SerializeField] private float gravity = -9.81f; // Значення гравітації
    private float yVelocity = 0f;  // Вертикальна швидкість персонажа

    private float nextFootstepTime;
    private Transform cameraTransform;
    private float rotationX = 0;
    private CharacterController characterController;
    private bool isSprinting = false;
    private string currentSurface = "Ground";

    private void Start()
    {
        cameraTransform = Camera.main.transform;
        Cursor.lockState = CursorLockMode.Locked;
        Cursor.visible = false;
        characterController = GetComponent<CharacterController>();
        nextFootstepTime = Time.time;
    }

    private void Update()
    {
        RotateCamera();
        Movement();
        ManageStamina();
    }

    private void RotateCamera()
    {
        float rotationInput = Input.GetAxis("Mouse X") * rotationSpeed;
        transform.Rotate(0, rotationInput, 0);

        rotationX -= Input.GetAxis("Mouse Y") * lookSpeed;
        rotationX = Mathf.Clamp(rotationX, -lookLimit, lookLimit);
        cameraTransform.localRotation = Quaternion.Euler(rotationX, 0, 0);
    }

    private void Movement()
    {
        float moveX = Input.GetAxis("Horizontal");
        float moveZ = Input.GetAxis("Vertical");

        Vector3 moveDirection = transform.TransformDirection(new Vector3(moveX, 0, moveZ));

        if (Input.GetKey(KeyCode.LeftShift) && stamina > 0)
        {
            moveDirection *= sprintSpeed;
            isSprinting = true;
        }
        else
        {
            moveDirection *= moveSpeed;
            isSprinting = false;
        }

        if (characterController.isGrounded)
        {
            yVelocity = 0f; // Обнуляємо вертикальну швидкість, якщо персонаж на землі
        }
        else
        {
            yVelocity += gravity * Time.deltaTime; // Додаємо гравітацію, коли персонаж не на землі
        }

        moveDirection.y = yVelocity; // Додаємо вертикальну швидкість до руху
        characterController.Move(moveDirection * Time.deltaTime);

        // Перевірка поверхні для звуку кроків
        RaycastHit hit;
        if (Physics.Raycast(transform.position, Vector3.down, out hit))
        {
            if (hit.collider.CompareTag("Footsteps/Wood"))
            {
                currentSurface = "Wood";
            }
            else if (hit.collider.CompareTag("Footsteps/Metal"))
            {
                currentSurface = "Metal";
            }
            else if (hit.collider.CompareTag("Footsteps/Ground"))
            {
                currentSurface = "Ground";
            }
        }

        PlayFootsteps();
    }

    private void PlayFootsteps()
    {
        if (IsMoving() && Time.time >= nextFootstepTime)
        {
            if (!footstepAudioSource.isPlaying)
            {
                AudioClip randomFootstepSound = GetFootstepSound();
                footstepAudioSource.clip = randomFootstepSound;
                footstepAudioSource.pitch = isSprinting ? 1.5f : 1.0f;
                nextFootstepTime = Time.time + (isSprinting ? nextSprintFootstepDelay : nextWalkFootstepDelay);
                footstepAudioSource.Play();
            }
        }
    }

    private AudioClip GetFootstepSound()
    {
        switch (currentSurface)
        {
            case "Wood":
                return GetRandomClipFromArray(woodFootstepSounds);
            case "Metal":
                return GetRandomClipFromArray(metalFootstepSounds);
            case "Ground":
                return GetRandomClipFromArray(groundFootstepSounds);
            default:
                return GetRandomClipFromArray(groundFootstepSounds);
        }
    }

    private AudioClip GetRandomClipFromArray(AudioClip[] clipArray)
    {
        if (clipArray != null && clipArray.Length > 0)
        {
            int randomIndex = Random.Range(0, clipArray.Length);
            return clipArray[randomIndex];
        }
        return null;
    }

    private void ManageStamina()
    {
        if (isSprinting)
        {
            stamina -= staminaDepletionRate * Time.deltaTime;
            stamina = Mathf.Clamp(stamina, 0, 100);

            if (stamina < 30 && !BreatheSound.isPlaying)
            {
                BreatheSound.Play();
            }
        }
        else if (stamina < 100)
        {
            stamina += (staminaDepletionRate / 2) * Time.deltaTime;
            stamina = Mathf.Clamp(stamina, 0, 100);
        }
    }

    public bool IsMoving()
    {
        float moveX = Input.GetAxis("Horizontal");
        float moveZ = Input.GetAxis("Vertical");
        return moveX != 0 || moveZ != 0;
    }

    public bool IsSprinting()
    {
        return isSprinting;
    }
}
